"""Local stub for emergentintegrations.llm.chat.

The real package ships only in the Emergent base image and is not on public PyPI.
This stub preserves the import surface used by backend/agents.py so the app can
run locally without the Emergent environment. LLM calls fail with a clear error.
"""


class UserMessage:
    def __init__(self, text=None, **kwargs):
        self.text = text
        for k, v in kwargs.items():
            setattr(self, k, v)


class LlmChat:
    def __init__(self, api_key="", session_id="", system_message=None, **kwargs):
        self.api_key = api_key
        self.session_id = session_id
        self.system_message = system_message
        self.provider = None
        self.model = None

    def with_model(self, provider, model):
        self.provider = provider
        self.model = model
        return self

    async def send_message(self, message):
        raise RuntimeError(
            "emergentintegrations stub: no real LLM backend in this sandbox. "
            "Install the Emergent base image package and set EMERGENT_LLM_KEY "
            "to run live agent pipelines."
        )
